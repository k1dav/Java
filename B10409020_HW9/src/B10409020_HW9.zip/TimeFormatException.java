/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author k1dave6412
 */
public class TimeFormatException extends Exception{
    public TimeFormatException (String message){
        super(message);
    }
    public TimeFormatException(){}
}
