/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author k1dave6412
 */
public interface Work {
    abstract String getDepartment();
    abstract void setDepartment();
    abstract double getSalary();
    abstract void setSalary();

}
