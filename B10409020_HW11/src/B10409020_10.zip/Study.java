/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author k1dave6412
 */
public interface Study {

    abstract String getMajor();
    abstract void setMajor();
    abstract String getDegree();
    abstract void setDegree();

}
